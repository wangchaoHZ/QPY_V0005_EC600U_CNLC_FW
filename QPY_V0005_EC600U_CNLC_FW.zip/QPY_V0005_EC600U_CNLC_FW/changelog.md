## Release History：
**[QPY_V0005_EC600U_CNLC_FW] 2022-04-02**

* zh:
* 1、fota升级增加HTTPS双向认证支持
* 2、fota升级增加下载进度上报功能
* 3、fota升级增加可选参数，配置fota升级下载校验完成后，不自动重启，有用户自己重启
* 4、增加发送AT指令的API
* 5、解决2G网络下，获取的信号强度总是99的问题
* 6、获取开机原因接口增加RTC唤醒、dump等原因
* 7、net.getSignal()接口返回值中增加sinr信噪比参数
* 8、拨号使用的APN、username合passward长度限制增大到64字节
* 9、增加对MIPI屏的支持
* 10、audio增加设置音量增益接口
* 11、拨号模块增加拨号去激活接口
* 12、umqtt功能优化
* 13、流播功能优化
* 14、新增LVGL触摸功能
* 15、sys_bus功能优化，解决可能会导致死锁的问题
* 16、优化ntp对时功能，新增一个可选的时区参数，控制NTP对时后的时间为哪个时区时间，默认为零时区
* 17、交互保护功能，增加设置密码功能，设置后，再次进入交互，需要输入密码
* 18、增大GC内存到832K
* 19、socket支持TCP服务器功能
* 20、新增gt9xx触摸驱动
* 21、新增对SD卡的读写支持

* en
* 1、fota upgrade adds HTTPS two-way authentication support
* 2、fota upgrade adds download progress reporting function
* 3、The fota upgrade adds optional parameters. After the configuration of the fota upgrade download and verification is completed, it will not restart automatically, and some users will restart by themselves.
* 4、Added API for sending AT commands
* 5、Solve the problem that the obtained signal strength is always 99 under the 2G network
* 6、Get the reason for booting the interface to add RTC wake-up, dump and other reasons
* 7、net.getSignal() Add the sinr signal-to-noise ratio parameter to the return value of the interface
* 8、The length limit of APN, username and passward used for dialing is increased to 64 bytes
* 9、Added support for MIPI screen
* 10、audio increase set volume gain interface
* 11、The dial-up module adds dial-up deactivation interface
* 12、umqtt function optimization
* 13、Streaming function optimization
* 14、Added LVGL touch function
* 15、sys_bus function optimization to solve the problem that may cause deadlock
* 16、Optimize the NTP time synchronization function, add an optional time zone parameter to control which time zone the time after NTP time synchronization is, the default time zone is zero
* 17、Interactive protection function, add the function of setting a password, after setting, to enter the interaction again, you need to enter a password
* 18、Increase GC memory to 832K
* 19、socket supports TCP server function
* 20、Added gt9xx touch driver
* 21、Added support for reading and writing SD cards

------

**[QPY_V0004_EC600U_CNLC_FW] 2021-12-21**

* 1、优化 M4A播放，避免播放失败问题

* 2、dataCall拨号模块，新增获取APN接口

* 3、audio增加听筒和喇叭通道设置pa功能

* 4、audio音量允许设置为0

* 5、解决展锐平台同一路GPIO的两个pin脚之间电平相互影响问题

* 6、checkNet功能优化，导入后，可直接通过checkNet.wait_network_connected(timeout) 方式使用，同时兼容以前的用法

* 7、request 新增文件上传功能，支持上传文件时自定义Content-Disposition 配置，支持多文件同时post到服务器

* 8、修复 socket 非阻塞模式失败的问题

* 9、修复 socket 设置一路 socket 的 timeout 会影响其他路 socket timeout 的问题

* 10、优化外部中断相关代码，避免硬件接触不良导致频繁中断触发，最终申请不到gc内存触发死机

* 11、machine_pin模块，增加设置GPIO方向接口

* 12、新增 sha1、ecb、base64相关加密算法

* 13、net模块增加设置APN接口

* 14、添加 CTRL_C 强制停止 mian.py 的功能

* 15、修复协程调度机制独占CPU引起的问题

* 16、新增WiFi定位功能

* 17、解决audio、tts队列播放功能不正常问题

* 18、解决外挂GNSS模块，GNSS无数据时运行报错问题

* 19、新增GPIO模拟IIC协议功能

* 20、新增设置log输出重定向功能

* 21、新增UART 485控制接口

* 22、新增keypad功能

* 23、拨号模块新增设置自定义DNS接口

* 24、新增USBNET功能

* 25、新增audio Tone播放接口

------

**[QPY_V0003_EC600U_CNLC_FW] 2021-10-20**

* 1、蓝牙BLE增加扫描上报过滤开关接口和获取蓝牙地址接口

* 2、解决号码过长导致短信功能dump问题

* 3、解决无信号时拨号重连失败问题

* 4、增加拍照和扫码功能

* 5、解决PWM部分频率设置失败问题

* 6、解决utime模块ticks_us()和ticks_ms()接口获取值不变的问题

* 7、新增asyncio携程支持

* 8、优化中断丢失问题

* 9、解决socket模块send ping timeout 重连失败问题

* 10、增加网络状态指示灯功能

------

**[QPY_V0002_EC600U_CNLC_FW] 2021-08-31**

* 1、增加可配置是否开机拨号功能

* 2、增加APTU组件

* 3、解决主线程sleep时，无法及时响应回调问题

* 4、增加移远云quecIot组件

* 5、增加BLE做主机端功能

* 6、socket模块增加IPV6支持

* 7、解决mqtt相关问题

* 8、解决录音模块相关问题

* 9、增加删除锁的API，用以删除已创建的锁

* 10、修复阿里云一型一密运行报错问题

* 11、修复app_fota返回值问题

* 12、提高浮点数精度至double类型

* 13、解决GPIO为输出模式初始化失败问题

* 14、解决拨号重连相关问题

**[QPY_V0001_EC600U_CNLC_FW] 2021-07-23**

* 1、增加BLE功能
* 2、增加audio功能
* 3、增加camera接口，目前仅支持gc032a
* 4、增加FOTA功能并统一展锐平台和ASR平台的FOTA升级接口
* 5、增加SPI功能
* 6、修复mutex相关问题
* 7、misc模块下新增USB子类,提供USB插拔检测接口以及注册回调接口
* 8、增加获取文件系统剩余空间接口
* 9、增加AAC、M4A音频文件流播放支持
* 10、增加流播放暂停、继续、跳转、seek接口
* 11、增加TS流播放支持
* 12、修复M4A大文件概率性无法播放问题
* 13、增加设置、获取时区接口
* 14、优化TS流播放稳定性
* 15、解决长短信编码问题
* 16、增加SIM卡热插拔控制接口及注册回调接口
* 17、mqtt增加连接超时、连接不了aliyun微消息等问题
* 18、解决调用获取邻区信息接口导致所有线程阻塞问题
* 19、解决音频录音导致的dump问题
* 20、umqtt/aliyun/txyun新增reconn参数，用于控制是否使用模块提供的重连机制
* 21、aliyun和tenxunyun新增查询连接状态接口
* 22、修复阿里云和腾讯云调用disconnect后出现dump问题
* 23、增加GNSS数据解析功能
* 24、其他已知问题的修复
* 25、增加RTMP协议栈支持
* 26、增加FLV流解析播放支持

* 27、增加RTC alarm接口，支持alarm自动开机

* 28、增加GNSS数据获取API

* 29、解决软狗相关BUG

* 30、解决record录音回调相关BUG

* 31、解决不能重复创建串口对象的问题

* 32、修复nandflash相关问题

* 33、音频文件播放，增加队列功能

* 34、新增语音通话功能

* 35、新增 jpeg 解码喝压缩功能，实现RGB565与 jpeg 的转换

* 36、解决ADC读取失败问题



更多版本请访问官网进行了解：

https://python.quectel.com/download